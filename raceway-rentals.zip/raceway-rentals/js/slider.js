const swiper = new Swiper('.swiper', {
    navigation: {
        nextEl: '.arr-right',
        prevEl: '.arr-left'
    }
  });