AOS.init({
    disable: 'mobile',
    duration: 800,
    once: true
});
