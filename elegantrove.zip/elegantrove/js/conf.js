const totalCost = document.querySelector('.cart-options__total-number');
totalCost.innerHTML = localStorage.getItem('totalPrice');